#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private DisplacementTFO[] cacheDisplacementTFO;

		
		public DisplacementTFO DisplacementTFO(bool requireFVG, string dispType, int stdLen, int stdX)
		{
			return DisplacementTFO(Input, requireFVG, dispType, stdLen, stdX);
		}


		
		public DisplacementTFO DisplacementTFO(ISeries<double> input, bool requireFVG, string dispType, int stdLen, int stdX)
		{
			if (cacheDisplacementTFO != null)
				for (int idx = 0; idx < cacheDisplacementTFO.Length; idx++)
					if (cacheDisplacementTFO[idx].RequireFVG == requireFVG && cacheDisplacementTFO[idx].DispType == dispType && cacheDisplacementTFO[idx].StdLen == stdLen && cacheDisplacementTFO[idx].StdX == stdX && cacheDisplacementTFO[idx].EqualsInput(input))
						return cacheDisplacementTFO[idx];
			return CacheIndicator<DisplacementTFO>(new DisplacementTFO(){ RequireFVG = requireFVG, DispType = dispType, StdLen = stdLen, StdX = stdX }, input, ref cacheDisplacementTFO);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.DisplacementTFO DisplacementTFO(bool requireFVG, string dispType, int stdLen, int stdX)
		{
			return indicator.DisplacementTFO(Input, requireFVG, dispType, stdLen, stdX);
		}


		
		public Indicators.DisplacementTFO DisplacementTFO(ISeries<double> input , bool requireFVG, string dispType, int stdLen, int stdX)
		{
			return indicator.DisplacementTFO(input, requireFVG, dispType, stdLen, stdX);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.DisplacementTFO DisplacementTFO(bool requireFVG, string dispType, int stdLen, int stdX)
		{
			return indicator.DisplacementTFO(Input, requireFVG, dispType, stdLen, stdX);
		}


		
		public Indicators.DisplacementTFO DisplacementTFO(ISeries<double> input , bool requireFVG, string dispType, int stdLen, int stdX)
		{
			return indicator.DisplacementTFO(input, requireFVG, dispType, stdLen, stdX);
		}

	}
}

#endregion
